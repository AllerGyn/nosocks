import ws from 'ws';

const PORT = 3333,
clients = {}; /* client side is 192.168.99.100:4444  */

(new ws.Server({
  port: PORT
}))
 .on('connection', ws => {
   let id = Math.random();
   clients[id] = ws;
   console.log('New connection');
   ws
    .on('message', message=> {
      console.log('message received: ' + message);
      Object.values(clients).forEach(client => client.send(message));
      if (message == 'quit') {
        process.nextTick( () => {throw new Error('Quitting!');} );
      }
   })
    .on('close', ()=>{
      console.log('Connection closed');
      delete clients[id];
   });
});
